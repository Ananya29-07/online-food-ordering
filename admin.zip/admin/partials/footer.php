<!---Footer Section Starts--->
<div class="footer">
           <div class="wrapper">
            <p class="text-center">Designed By <a href="#">Ananya Gupta</a></p>
           </div>
        </div>
        <!---Footer Section Ends--->
    </body>
</html>      