<?php
   //Start session
   session_start();
   //Used to store constants from creating new
   define('SITEURL','http://localhost/Online-food-order/');
   define('LOCALHOST','localhost');
   define('DB_USERNAME','root');
   define('DB_PASSWORD','');
   define('DB_NAME','online-food');
   $conn=mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error()); //Database connection
   $db_select=mysqli_select_db($conn, DB_NAME) or die(mysqli_error()); //Selecting Database
?>