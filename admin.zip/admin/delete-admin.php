<?php
   include('../config/constants.php');
   $id=$_GET['id'];
   $sql="DELETE FROM admin WHERE id=$id";
   $res=mysqli_query($conn,$sql);
   if($res==TRUE)
   {
    $_SESSION['delete']="Admin Deleted Successfully";
    header("location:".SITEURL.'admin/manage-admin.php');
   }
   else
   {
    $_SESSION['delete']="Admin Deletion Failed";
    header("location:".SITEURL.'admin/manage-admin.php');
   }
?>