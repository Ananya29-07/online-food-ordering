<?php include('../config/constants.php');?>
<html>
    <head>
        <title>Restaurant Login</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body style="background-color:#d0cdca; background-image:url('../images/transparentlogo.png'); background-size: 50% 80%; background-repeat: no-repeat;
     background-attachment: center;  background-position: center;">
        <div class="login">
            <h2 class="text-center">Login</h2><br><br>
            <?php
                if(isset($_SESSION['login']))
                {
                  echo $_SESSION['login'];
                  unset($_SESSION['login']);
                }
                if(isset($_SESSION['login-message']))
                {
                  echo $_SESSION['login-message'];
                  unset($_SESSION['login-message']);
                }
            ?> 
            <form action="" method="POST" class="text-center" style="background-image: url('../images/logo.png');">
                <b>Username:<b><br><br>
                <input type="text" name="username" placeholder="Enter Username" style="border-style:none; padding:2%; font-weight:bold;"><br><br>
                <b>Password:<b><br><br>
                <input type="password" name="password" placeholder="Enter Password" style="border-style:none; padding:2%; font-weight:bold;"><br><br>
                <input type="submit" name="submit" value="Login" class="btn-secondary" style="padding: 2%; width: 30%; font-weight:bold;"><br><br>
            </form>
            <p class="text-center" style="font-weight:bold;">Created By <a href="#" style="text-decoration: none; color: #035c00; font-weight:bold;">Ananya Gupta</a></p>
        </div>
    </body>
</html>
<?php
  if(isset($_POST['submit']))
  {
    $username=$_POST['username'];
    $password=md5($_POST['password']);
    $sql="SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $res=mysqli_query($conn,$sql);
    $count=mysqli_num_rows($res);
    if($count==1)
    {
        $_SESSION['login'];
        $_SESSION['user']=$username;
        header("location:".SITEURL.'admin/');
    }
    else
    {
        $_SESSION['login']="Username or Password don't match";
        header("location:".SITEURL.'admin/login.php');
    }
  }
?>