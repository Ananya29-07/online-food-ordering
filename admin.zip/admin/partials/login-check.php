<?php
  if(!isset($_SESSION['user']))
  {
     $_SESSION['login-message']="<div style='color:rgb(139, 0, 0); font-weight:bold;'>Login to Access Admin Panel</div>";
     header('location:'.SITEURL.'admin/login.php');
  }
?>