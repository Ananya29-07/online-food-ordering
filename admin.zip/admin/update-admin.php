<?php
   include('partials/menu.php');
?>   
 <div class="main-content">
    <div class="wrapper">
        <h2><strong>UPDATE ADMIN</strong></h2><br>
        <?php
          $id=$_GET['id'];
          $sql="SELECT * FROM admin WHERE id=$id";
          $res=mysqli_query($conn,$sql);
          if($res==TRUE)
          {
            $count=mysqli_num_rows($res);
            if($count==1)
            {
                $rows=mysqli_fetch_assoc($res);
                $name=$rows['name'];
                $username=$rows['username'];
            }
          }
        ?>
        <form action="" method="POST">
            <table class="tbl-30">
                <tr>
                    <td>Name:</td>
                    <td><input type="text" name="name" value="<?php echo $name ?>"></td>
                </tr>
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" value="<?php echo $username ?>"></td>
                </tr>
                <tr>
                    <input type="hidden" name="id" value="<?php echo $id;?>">
                    <td colspan="2"><input type="submit" name="submit" value="Update Admin" class="btn-secondary"></td>
                </tr>
            </table>
        </form>
    </div>
</div>    
<?php
  if(isset($_POST['submit']))
  {
    $id=$_POST['id'];
    $name=$_POST['name'];
    $username=$_POST['username'];
    $sql="UPDATE admin SET
        name='$name',
        username='$username'
        WHERE id='$id'
        ";
        $res=mysqli_query($conn, $sql);
        if($res==TRUE)
        {
         $_SESSION['update']="Admin Updated Successfully";
         header("location:".SITEURL.'admin/manage-admin.php');
        }
        else
        {
          $_SESSION['update']="Admin Updation Failed";
          header("location:".SITEURL.'admin/manage-admin.php');
        }  
  }
?>
<?php
   include('partials/footer.php');
?>      