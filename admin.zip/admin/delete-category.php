<?php
include('../config/constants.php');
   if(isset($_GET['id'])AND isset($_GET['image_name']))
   {
    $id=$_GET['id'];
    $image_name=$_GET['image_name'];
    if($image_name!="")
    {
        $path="../images/category/".$image_name;
        $remove=unlink($path);
        if($remove==FALSE)
        {
            $_SESSION['remove']="Failed to Delete Category";
            header('location:'.SITEURL.'admin/manage-category.php');
            die();
        }
    }
    $sql="DELETE FROM categories WHERE id=$id";
    $res=mysqli_query($conn,$sql);
    if($res==TRUE)
    {
     $_SESSION['delete']="Category Deleted Successfully";
     header('location:'.SITEURL.'admin/manage-category.php');
    }
    else
    {
     $_SESSION['delete']="Category Deletion Failed";
     header('location:'.SITEURL.'admin/manage-category.php');
    }
   }
   else
   {
      header('location:'.SITEURL.'admin/manage-category.php');
   }
?>